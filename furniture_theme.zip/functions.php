<?php
//////Iskljucivanje Gutenberg editora//////

    add_filter('use_block_editor_for_post', '__return_false', 10);


//////Ukljucivanje CSS i JS//////

// Install jQuery 3.4.1 - jQuery CDN
function vpsb_custom_jquery() {

    // obrisi default jquery koji wp ubacuje sam
    wp_deregister_script('jquery');
    wp_register_script('jquery', ("https://code.jquery.com/jquery-3.4.1.min.js"), false);
    wp_enqueue_script('jquery');
    }
add_action('wp_enqueue_scripts', 'vpsb_custom_jquery');

function enqueue_custom_styles_and_scripts() {
    $theme_version = wp_get_theme()->get('Version');

   
    // Enqueue CSS Libraries
    wp_enqueue_style( 'style', get_stylesheet_uri(), array(), $theme_version, 'all' );
  
}

add_action('wp_enqueue_scripts', 'enqueue_custom_styles_and_scripts');
 
//////Ubacivanje menija na sajt//////

    register_nav_menus( array(
        'furniture_menu' => 'Main Menu'
    ) );

//////Registrovanje Theme setings//////

    if( function_exists('acf_add_options_page') ) {
        
        if( function_exists('acf_add_options_page') ) {
        
            acf_add_options_page(array(
                'page_title'    => 'Theme General Settings',
                'menu_title'    => 'Theme Settings',
                'menu_slug'     => 'theme-general-settings',
                'capability'    => 'edit_posts',
                'redirect'      => false
            ));
        
        }
    }   
    // Register Custom Post Type

    // Register Custom Post Type
function rooms_post() {

	$labels = array(
		'name'                  => _x( 'Rooms', 'Post Type General Name', 'text_domain' ),
		'singular_name'         => _x( 'Room', 'Post Type Singular Name', 'text_domain' ),
		'menu_name'             => __( 'Rooms', 'text_domain' ),
		'name_admin_bar'        => __( 'Post Type', 'text_domain' ),
		'archives'              => __( 'Item Archives', 'text_domain' ),
		'attributes'            => __( 'Item Attributes', 'text_domain' ),
		'parent_item_colon'     => __( 'Parent Item:', 'text_domain' ),
		'all_items'             => __( 'All Items', 'text_domain' ),
		'add_new_item'          => __( 'Add New Item', 'text_domain' ),
		'add_new'               => __( 'Add New', 'text_domain' ),
		'new_item'              => __( 'New Item', 'text_domain' ),
		'edit_item'             => __( 'Edit Item', 'text_domain' ),
		'update_item'           => __( 'Update Item', 'text_domain' ),
		'view_item'             => __( 'View Item', 'text_domain' ),
		'view_items'            => __( 'View Items', 'text_domain' ),
		'search_items'          => __( 'Search Item', 'text_domain' ),
		'not_found'             => __( 'Not found', 'text_domain' ),
		'not_found_in_trash'    => __( 'Not found in Trash', 'text_domain' ),
		'featured_image'        => __( 'Featured Image', 'text_domain' ),
		'set_featured_image'    => __( 'Set featured image', 'text_domain' ),
		'remove_featured_image' => __( 'Remove featured image', 'text_domain' ),
		'use_featured_image'    => __( 'Use as featured image', 'text_domain' ),
		'insert_into_item'      => __( 'Insert into item', 'text_domain' ),
		'uploaded_to_this_item' => __( 'Uploaded to this item', 'text_domain' ),
		'items_list'            => __( 'Items list', 'text_domain' ),
		'items_list_navigation' => __( 'Items list navigation', 'text_domain' ),
		'filter_items_list'     => __( 'Filter items list', 'text_domain' ),
	);
	$args = array(
		'label'                 => __( 'Room', 'text_domain' ),
		'description'           => __( 'Post Type Description', 'text_domain' ),
		'labels'                => $labels,
		'supports'              => array( 'title', 'editor' ),
		'hierarchical'          => false,
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => true,
		'menu_position'         => 5,
		'show_in_admin_bar'     => true,
		'show_in_nav_menus'     => true,
		'can_export'            => true,
		'has_archive'           => true,
		'exclude_from_search'   => false,
		'publicly_queryable'    => true,
		'capability_type'       => 'page',
	);
	register_post_type( 'rooms', $args );

}
add_action( 'init', 'rooms_post', 0 );




// Let us create Taxonomy for Custom Post Type
add_action( 'init', 'crunchify_create_deals_custom_taxonomy', 0 );
//create a custom taxonomy name it "type" for your posts
function crunchify_create_deals_custom_taxonomy() {
  $labels = array(
    'name' => _x( 'Sobe', 'taxonomy general name' ),
    'singular_name' => _x( 'Soba', 'taxonomy singular name' ),
    'search_items' =>  __( 'Pretrazi sobe' ),
    'all_items' => __( 'Sve sobe' ),
    'parent_item' => __( 'Parent Type' ),
    'parent_item_colon' => __( 'Parent Type:' ),
    'edit_item' => __( 'Edit Type' ), 
    'update_item' => __( 'Update Type' ),
    'add_new_item' => __( 'Dodaj novu sobu' ),
    'new_item_name' => __( 'New Type Name' ),
    'menu_name' => __( 'Vrsta sobe' ),
  );     
  register_taxonomy('types',array('rooms'), array(
    'hierarchical' => true,
    'labels' => $labels,
    'show_ui' => true,
    'show_admin_column' => true,
    'query_var' => true,
    'rewrite' => array( 'slug' => 'type' ),
  ));
}


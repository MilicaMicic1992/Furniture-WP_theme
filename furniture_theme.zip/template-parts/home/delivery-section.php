
<!--start DELIVERY-->
<?php if ( have_rows('delivery_repeater') ) : ?>
    <section class="delivery">
       <div class="container">
          <div class="delivery-body">

    <?php while( have_rows('delivery_repeater') ) : the_row();

        $delivery_image = get_sub_field('delivery_image');
        $delivery_title = get_sub_field('delivery_title');
        $delivery_text  = get_sub_field('delivery_text');
    ?>
        <div class="delivery-body-item">
            <img src="<?php echo  $delivery_image['url'];?>"
                 alt="<?php echo  $delivery_image['alt'];?>">
                <div class="delivery-flex">
                    <h5><?php echo $delivery_title; ?></h5>
                    <p><?php  echo $delivery_text; ?></p>
                </div><!--end delivery-flex-->
        </div><!--end delivery-body-item-->
    <?php endwhile; ?>
           
         </div><!--end delivery-body-->
       </div><!--end container-->
     </section><!--end delivery-->
<?php endif; ?>
<!--end DELIVERY-->
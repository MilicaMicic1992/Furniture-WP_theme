<!--start MAIL-->
<section class="mail">
    <div class="container">
        <div class="mail-body">
            <h2>Join Our Mailing List</h2>
            <p>Sign up to receive inspiration, product updates, and special offers from our team.</p>
        </div><!--end mail-body-->
        <form class="form">
            <input type="email"  
            class="email" placeholder="example@gmail.com">
            <button class="button">Submit</button>
        </form>
    </div><!--end container-->
</section><!--end mail-->
<!--end MAIL-->
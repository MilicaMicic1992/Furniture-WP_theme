<!--
 **********************************************
 * Project: Furniture
 **********************************************
 * Developed by: MIlica Micic
   + design: Figma
   + e-mail: <milica.maksimovic0922@gmail.com>
   + html, css, vanilla js & php
   + responsive page
 *********************************************
-->

<!DOCTYPE html>
<html <?php language_attributes ();?>>
   <head>
      <!-- basic -->
      <meta charset="<?php bloginfo(' charset '); ?>">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <!-- mobile metas -->
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="viewport" content="initial-scale=1, maximum-scale=1">
      <!-- site metas -->
      <title><?php wp_title();?> </title>
      <meta name="keywords" content="">
      <meta name="description" content="">
      <meta name="author" content="">     
      <?php wp_head(); ?>
   </head>
   <!-- body -->
   <body class="main-layout" <?php body_class();?>>
      
<!--start HEADER-->
<header>
    <div class="container">
        <div class="header-body">
            <div class="header-body-item">
            <a href="<?php echo home_url();?>">  
              <?php
                $logo = get_field('logo', 'option');
              ?>
                 <img src="<?php echo $logo['url']?>"
                      alt="<?php echo $logo['alt']?>">
            </a>  
            </div><!--end header-body-item-->
                <div id="nav">
                     <?php
                           $menu_args = array(
                           'theme_location'  => 'furniture_menu',
                           'menu_class'      => 'nav-list',      
                              );
                           wp_nav_menu($menu_args);
                           ?>                  
                </div><!--end nav-->
                <div id="hamburger">
                    <span class="hamburger-line"></span>
                </div><!--end hamburger-->
        </div><!--end header-body-->
    </div><!--end container-->
</header>
<!--end HEADER-->  

      
<!--start FOOTER-->
<footer>
    <div class="container">
        <div class="footer-body">
            <div class="footer-item">
                <h4><?php the_field('footer_title');?></h4>
                <p><?php the_field('footer_text');?></p>
                <h4><?php the_field('footer_subtitle');?></h4>
            </div><!--end footer-item-->
            <div class="footer-item">
                <h4><?php the_field('footer_shop');?></h4>
                <div class="footer-img">
                    <?php
                    $footer_pcs_1 = get_field('footer_pcs_1');
                    $footer_pcs_2 = get_field('footer_pcs_2');
                    $footer_pcs_3 = get_field('footer_pcs_3');
                    $footer_pcs_4 = get_field('footer_pcs_4');
                    ?>
                    <img src="<?php echo $footer_pcs_1['url'];?>" 
                         alt="<?php echo $footer_pcs_1['alt'];?>">
                    <img src="<?php echo $footer_pcs_2['url'];?>" 
                         alt="<?php echo $footer_pcs_2['alt'];?>">
                    <img src="<?php echo $footer_pcs_3['url'];?>" 
                         alt="<?php echo $footer_pcs_3['alt'];?>">
                    <img src="<?php echo $footer_pcs_4['url'];?>" 
                         alt="<?php echo $footer_pcs_4['alt'];?>">      
                    
                </div><!--end footer-img-->
            </div><!--end footer-item-->
        </div><!--end footer-body-->
    </div><!--end container-->
</footer><!--end footer-->
<!--end FOOTER-->






<script>

const navMenu = document.getElementById("nav");
const navToggle = document.getElementById("hamburger");

navToggle.addEventListener('click', function(){
    navMenu.classList.toggle('is-active');
})

</script>      
      <?php wp_footer(); ?>
   </body>
</html>
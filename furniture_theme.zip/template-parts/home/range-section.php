<!--start RANGE-->
<section class="range">
    <div class="container">
        <div class="range-title">
            <h2><?php the_field('range_title');?></h2>
            <p><?php the_field('range_text');?></p>
        </div><!--end range title-->
        <div class="range-body">
<?php
        $args = array(
            'post_type' => 'Rooms',   // Custom post type name
            'posts_per_page' => -1,    // Display all members
        );

        $members_query = new WP_Query($args);

        if ($members_query->have_posts()) {
            while ($members_query->have_posts()) {
                $members_query->the_post();

                // Get ACF values for the current member
                $room_image = get_field('room_image');
                $room_title = get_field('room_title');
                ?>
        
            <div class="range-body-item">
                        <img src="<?php echo $room_image['url'];?>" 
                            alt="<?php echo $room_image['alt'];?>">
                        <h5><?php echo $room_title;?></h5>
                    </div><!--end range-body-item-->
         

                <?php
            }
            wp_reset_postdata(); // Reset the query to the main post
        }
?>
       </div><!--end range-body-->
    </div><!--end container-->
</section><!--end range-->
<!--end RANGE-->













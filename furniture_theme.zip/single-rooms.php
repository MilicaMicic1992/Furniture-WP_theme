<?php
get_header();
?>
<?php
the_title();
?>


<?php
    $room_image = get_field('room_image');
    $room_title = get_field('room_title');
?>

    <div class="range-body">
    <div class="range-body-item">
                <img src="<?php echo $room_image['url'];?>" 
                     alt="<?php echo $room_image['alt'];?>">
                <h5><?php echo $room_title;?></h5>
            </div><!--end range-body-item-->
    </div><!--end range-body-->
 







        
    
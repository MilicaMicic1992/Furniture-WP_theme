<?php
/*
Template name: Home page
*/ 
get_header();
?>

<?php get_template_part('template-parts/home/hero-section');?>
<?php get_template_part('template-parts/home/delivery-section');?>
<?php get_template_part('template-parts/home/collection-section');?>
<?php get_template_part('template-parts/home/beautify-section');?>
<?php get_template_part('template-parts/home/range-section');?>
<?php get_template_part('template-parts/home/work-section');?>
<?php get_template_part('template-parts/home/mail-section');?>



<?php get_footer();?>
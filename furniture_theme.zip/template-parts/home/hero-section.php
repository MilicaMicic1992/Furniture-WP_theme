<!--start HERO-->

<?php 
$image = get_field('image');
$size = "full";
$hero_background_image = wp_get_attachment_image_src($image, $size);

?>

<section class="hero"  style="background-image: url(<?php echo $hero_background_image[0]; ?> );">
        <div class="hero-body">
            <?php
                $hero_title               = get_field('hero_title');
                $hero_subtitle            = get_field('hero_subtitle');
                $hero_content             = get_field('hero_content');
                $hero_button              = get_field('hero_button');
                
            ?>
            <div class="hero-body-item">
                <p><?php echo $hero_subtitle?></p>
                <h1><?php echo $hero_title?></h1>
                <p><?php echo $hero_content ?></p>
                <button class="button"><?php echo $hero_button?></button>
            </div><!--end hero-body-item-->
        </div><!--end hero-body-->
</section><!--end hero-->
<!--end HERO-->
<?php
/*
Template name: Milica acf
*/ 
get_header();
?>

<div class="container" >

<?php if ( have_rows( 'acf-sadrzaj' ) ) : ?>
    
    <?php while ( have_rows('acf-sadrzaj' ) ) : the_row();
        $layout = get_row_layout();
        ?>
         
    <!--Slika levo, tekst desno-->
        <?php if ( $layout == 'zadatak1' ) : 
            $image_zadatak1 = get_sub_field('image_zadatak1');
            $text_zadatak1  = get_sub_field('text_zadatak1');
            ?>
            <div class="zadatak1" style="display:flex;  justify-content:space-between; max-width:600px; align-items:center;">
              <div >
                    <img src="<?php echo $image_zadatak1['url'];?>" 
                         alt="<?php echo $image_zadatak1['alt'];?>">
              </div>
              <div>
                   <p><?php echo $text_zadatak1?></p>
              </div>
            </div><!--end zadatak1-->  
        <?php endif; ?>

    <!--Slika desno, tekst levo-->
    <?php if ( $layout == 'zadatak2' ) : 
            $image_zadatak2 = get_sub_field('image_zadatak2');
            $text_zadatak2  = get_sub_field('text_zadatak2');
            ?>
            <div class="zadatak2" style="display:flex;  justify-content:space-between; max-width:600px; align-items:center;">
              <div>
                   <p><?php echo $text_zadatak2?></p>
              </div>
              <div>
                    <img src="<?php echo $image_zadatak2['url'];?>" 
                         alt="<?php echo $image_zadatak2['alt'];?>">
              </div>
            </div><!--end zadatak1-->  
        <?php endif; ?>

    <!--Vise slika-->
    <?php if ( $layout == 'zadatak3' ) : ?>
            <?php if ( have_rows('repeater-slike') ) : ?>
              <div class="slike_grid" style="display:grid; grid-template-columns:repeat(auto-fit, minmax(250px, 1fr)); gap:20px;margin:50px;">
                <?php while( have_rows('repeater-slike') ) : the_row();
                  $slike_repeater = get_sub_field('slike_repeater');
                ?>
                    <div>
                        <img src="<?php echo $slike_repeater['url'];?>" 
                             alt="<?php echo $slike_repeater['alt'];?>">
                    </div>           
                <?php endwhile; ?>
               </div><!--end slike_grid-->
            <?php endif; ?>
        <?php endif; ?>

    <!--Youtube video-->
    <?php if ( $layout == 'zadatak4' ) :
      
        ?>
            <?php the_sub_field('youtube_url') ?>
            
        <?php endif; ?>

    <!--Jedna slika-->
    <?php if ( $layout == 'zadatak5' ) : 
        $slika_zadatak5 = get_sub_field('slika_zadatak5');
        ?>
           <div>
           <img src="<?php echo $slika_zadatak5['url'];?>" 
                alt="<?php echo $slika_zadatak5['alt'];?>">
            </div>
        <?php endif; ?>

    <!--Dve slike-->
    <?php if ( $layout == 'zadatak6' ) :
        $slika6_1 = get_sub_field('slika6_1');
        $slika6_2 = get_sub_field('slika6_2');
        ?>
            <div style="display:flex; justify-content:space-between; align-items:center; margin:100px">
            <img src="<?php echo $slika6_1['url'];?>" 
                 alt="<?php echo $slika6_1['alt'];?>">
            <img src="<?php echo $slika6_2['url'];?>" 
                 alt="<?php echo $slika6_2['alt'];?>">
            </div>
        <?php endif; ?>

    <!--Tri slike-->
    <?php if ( $layout == 'zadatak7' ) : 
        $slika7_1 = get_sub_field('slika7_1');
        $slika7_2 = get_sub_field('slika7_2');
        $slika7_3 = get_sub_field('slika7_3');

        ?>
            <div style="display:flex; justify-content:space-between; align-items:center; margin:100px">
            <img src="<?php echo $slika7_1['url'];?>" 
                 alt="<?php echo $slika7_1['alt'];?>">
            <img src="<?php echo $slika7_2['url'];?>" 
                 alt="<?php echo $slika7_2['alt'];?>">
            <img src="<?php echo $slika7_3['url'];?>" 
                 alt="<?php echo $slika7_3['alt'];?>">
            </div>
        <?php endif; ?>

    <?php endwhile; ?>
<?php endif; ?>

</div><!--end container-->


<?php get_footer();?>


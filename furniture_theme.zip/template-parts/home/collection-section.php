
<!--start COLLECTION-->
<section class="collection">
        <div class="container">
            <div class="collection-title">
                <h2><?php the_field('collection_title');?></h2>
                <p><?php the_field('collection_text');?></p>
            </div><!--end collection-title-->
<?php if ( have_rows('collestion_repeater') ) : ?>
            <div class="collection-body">
    <?php while( have_rows('collestion_repeater') ) : the_row(); 
      $collection_image = get_sub_field('collestion_image');  
    ?>
             <div class="collection-body-item">
                <img src="<?php echo $collection_image['url'];?>" 
                     alt="<?php echo $collection_image['alt'];?>">
            </div><!--end collection-body-item-->

    <?php endwhile; ?>
      </div><!--end collection-body-->
<?php endif; ?>
</div><!--end container-->
</section><!--end section-->
<!--end COLLECTION-->
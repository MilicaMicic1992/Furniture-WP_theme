<!--start WORK-->
<section class="work">
    <div class="container">
        <div class="work-title">
            <h2><?php the_field('work_title');?></h2>
            <p><?php the_field('work_text');?></p>
        </div><!--end work-title-->
    <div class="work-body">
    
<?php  if ( have_rows('work_repeater') ) : ?>
    <?php $counter = 1; while( have_rows('work_repeater') ) : the_row();
      
       $work_img        = get_sub_field('work_img');
       $work_img_title  = get_sub_field('work_img_title');
       $work_img_text   = get_sub_field('work_img_text');
     ?>
            <div class="work-body-item">
                <div class="work-img">
                    <img src="<?php echo $work_img['url'];?>" 
                         alt="<?php echo $work_img['alt'];?>">
                         <span class="item-counter">
                            <?php echo $counter; ?>
                         </span>
                </div>
                <h5><?php echo $work_img_title;?></h5>
                <p><?php echo $work_img_text;?></p>
            </div><!--end work-body-item-->

    <?php $counter++; endwhile;?>
 <?php endif; ?>

   </div><!--end work-body-->
  </div><!--end container-->
</section><!--end work-->
<!--END WORK-->

       
               
       
           



<!--start BEAUTIFY-->
<?php
    $beautify_title = get_field('beautify_title');
    $beautify_text = get_field('beautify_text');
    $beautify_image = get_field('beautify_image');
    $beautify_bttn = get_field('beautify_bttn');

?>

<section class="beautify">
    <div class="container">
        <div class="beautify-body">
            <div class="beautify-body-item">
                <h2><?php echo $beautify_title;?></h2>
                <p><?php echo $beautify_text;?></p>
                <button class="button"><?php echo $beautify_bttn;?></button>
            </div><!--end beautify-body-item-->
            <div class="beautify-body-item">
              
                <img src="<?php echo $beautify_image['url'];?>" 
                      alt="<?php echo $beautify_image['url'];?>">
            </div><!--end beautify-body-item-->
        </div><!--end beautify-body-->
    </div><!--end container-->
</section><!--end beautify-->
<!--end BEAUTIFY-->